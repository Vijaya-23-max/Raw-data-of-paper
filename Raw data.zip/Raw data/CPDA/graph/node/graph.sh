xgraph PDR_CPDA -x "Node" -y "PDR" -t "Node Vs PDR" -lw 2 -tk -P -ly 90,105
xgraph Delay_CPDA -x "Node" -y "Delay" -t "Node Vs Delay" -lw 2 -tk -P -ly -30e-3,250e-3
xgraph Control_OH_CPDA -x "Node" -y "Control_overhead" -t "Node Vs Control_overhead" -lw 2 -tk -P
xgraph Normalized_OH_CPDA -x "Node" -y "Normalized_Overheads" -t "Node Vs Normalized_Overheads" -lw 2 -tk -P 
xgraph Dropping_Ratio_CPDA -x "Node" -y "Dropping_Ratio" -t "Node Vs Dropping_Ratio" -lw 2 -tk -P -ly -2,5
xgraph Pkts_Dropped_CPDA -x "Node" -y "Pkts_Dropped" -t "Node Vs Pkts_Dropped" -lw 2 -tk -P -ly -30,90
xgraph Avg_Energy_CPDA -x "Node" -y "Avg_Energy" -t "Node Vs Average_Energy_Consumptions" -lw 2 -tk -P -ly -300e-3,900e-3
xgraph Residual_Energy_CPDA -x "Node" -y "Residual_Energy" -t "Node Vs Average_Residual_Energy" -lw 2 -tk -P -ly 99.20,100
xgraph Jitter_CPDA -x "Node" -y "Jitter" -t "Node Vs Jitter" -lw 2 -tk -P -ly 90e-3,110e-3
xgraph Throughput_CPDA -x "Node" -y "Throughput" -t "Node Vs Throughput" -lw 2 -tk -P -ly 140e3,170e3




