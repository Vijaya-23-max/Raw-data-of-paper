xgraph PDR_CPDA -x "Coverage" -y "PDR" -t "Coverage Vs PDR" -lw 2 -tk -P -ly 90,106
xgraph Delay_CPDA -x "Coverage" -y "Delay" -t "Coverage Vs Delay" -lw 2 -tk -P -ly -700e-3,1300e-3
xgraph Control_OH_CPDA -x "Coverage" -y "Control_overhead" -t "Coverage Vs Control_overhead" -lw 2 -tk -P -ly 10e3,12.40e3
xgraph Normalized_OH_CPDA -x "Coverage" -y "Normalized_Overheads" -t "Coverage Vs Normalized_Overheads" -lw 2 -tk -P -ly 4,8
xgraph Dropping_Ratio_CPDA -x "Coverage" -y "Dropping_Ratio" -t "Coverage Vs Dropping_Ratio" -lw 2 -tk -P -ly -2,5
xgraph Pkts_Dropped_CPDA -x "Coverage" -y "Pkts_Dropped" -t "Coverage Vs Pkts_Dropped" -lw 2 -tk -P -ly -50,100
xgraph Avg_Energy_CPDA -x "Coverage" -y "Avg_Energy" -t "Coverage Vs Average_Energy_Consumptions" -lw 2 -tk -P -ly 200e-3,800e-3
xgraph Residual_Energy_CPDA -x "Coverage" -y "Residual_Energy" -t "Coverage Vs Average_Residual_Energy" -lw 2 -tk -P -ly 98.60,100.60
xgraph Jitter_CPDA -x "Coverage" -y "Jitter" -t "Coverage Vs Jitter" -lw 2 -tk -P -ly 90e-3,110e-3
xgraph Throughput_CPDA -x "Coverage" -y "Throughput" -t "Coverage Vs Throughput" -lw 2 -tk -P -ly 140e3,190e3




