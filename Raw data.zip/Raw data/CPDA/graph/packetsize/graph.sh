xgraph PDR_CPDA -x "Packetsize" -y "PDR" -t "Packetsize Vs PDR" -lw 2 -tk -P -ly 98,101
xgraph Delay_CPDA -x "Packetsize" -y "Delay" -t "Packetsize Vs Delay" -lw 2 -tk -P -ly 50e-3,200e-3
xgraph Control_OH_CPDA -x "Packetsize" -y "Control_overhead" -t "Packetsize Vs Control_overhead" -lw 2 -tk -P -ly 10.80e3,11.70e3
xgraph Normalized_OH_CPDA -x "Packetsize" -y "Normalized_Overheads" -t "Packetsize Vs Normalized_Overheads" -lw 2 -tk -P -ly 5.8,6.7
xgraph Dropping_Ratio_CPDA -x "Packetsize" -y "Dropping_Ratio" -t "Packetsize Vs Dropping_Ratio" -lw 2 -tk -P -ly -200e-3,1200e-3
xgraph Pkts_Dropped_CPDA -x "Packetsize" -y "Pkts_Dropped" -t "Packetsize Vs Pkts_Dropped" -lw 2 -tk -P -ly -5,23
xgraph Avg_Energy_CPDA -x "Packetsize" -y "Avg_Energy" -t "Packetsize Vs Average_Energy_Consumptions" -lw 2 -tk -P -ly 200e-3,700e-3
xgraph Residual_Energy_CPDA -x "Packetsize" -y "Residual_Energy" -t "Packetsize Vs Average_Residual_Energy" -lw 2 -tk -P -ly 99,100
xgraph Jitter_CPDA -x "Packetsize" -y "Jitter" -t "Packetsize Vs Jitter" -lw 2 -tk -P -ly 94e-3,105e-3
xgraph Throughput_CPDA -x "Packetsize" -y "Throughput" -t "Packetsize Vs Throughput" -lw 2 -tk -P




