xgraph PDR_CPDA -x "Pausetime" -y "PDR" -t "Pausetime Vs PDR" -lw 2 -tk -P -ly 97,101
xgraph Delay_CPDA -x "Pausetime" -y "Delay" -t "Pausetime Vs Delay" -lw 2 -tk -P -ly -100e-3,350e-3
xgraph Control_OH_CPDA -x "Pausetime" -y "Control_overhead" -t "Pausetime Vs Control_overhead" -lw 2 -tk -P -ly 10.6e3,12e3
xgraph Normalized_OH_CPDA -x "Pausetime" -y "Normalized_Overheads" -t "Pausetime Vs Normalized_Overheads" -lw 2 -tk -P -ly 5.8,7
xgraph Dropping_Ratio_CPDA -x "Pausetime" -y "Dropping_Ratio" -t "Pausetime Vs Dropping_Ratio" -lw 2 -tk -P -ly -500e-3,1500e-3
xgraph Pkts_Dropped_CPDA -x "Pausetime" -y "Pkts_Dropped" -t "Pausetime Vs Pkts_Dropped" -lw 2 -tk -P -ly -10,25
xgraph Avg_Energy_CPDA -x "Pausetime" -y "Avg_Energy" -t "Pausetime Vs Average_Energy_Consumptions" -lw 2 -tk -P -ly -150e-3,700e-3
xgraph Residual_Energy_CPDA -x "Pausetime" -y "Residual_Energy" -t "Pausetime Vs Average_Residual_Energy" -lw 2 -tk -P -ly 99,100
xgraph Jitter_CPDA -x "Pausetime" -y "Jitter" -t "Pausetime Vs Jitter" -lw 2 -tk -P -ly 96e-3,104e-3
xgraph Throughput_CPDA -x "Pausetime" -y "Throughput" -t "Pausetime Vs Throughput" -lw 2 -tk -P -ly 150e3,170e3




