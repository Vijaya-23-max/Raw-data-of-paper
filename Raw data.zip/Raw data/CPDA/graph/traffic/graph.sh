xgraph PDR_CPDA -x "Traffic" -y "PDR" -t "Traffic Vs PDR" -lw 2 -tk -P -ly 20,120
xgraph Delay_CPDA -x "Traffic" -y "Delay" -t "Traffic Vs Delay" -lw 2 -tk -P -ly -6,8
xgraph Control_OH_CPDA -x "Traffic" -y "Control_overhead" -t "Traffic Vs Control_overhead" -lw 2 -tk -P -ly 5e3,23e3
xgraph Normalized_OH_CPDA -x "Traffic" -y "Normalized_Overheads" -t "Traffic Vs Normalized_Overheads" -lw 2 -tk -P -ly 0,9
xgraph Dropping_Ratio_CPDA -x "Traffic" -y "Dropping_Ratio" -t "Traffic Vs Dropping_Ratio" -lw 2 -tk -P -ly -25,50
xgraph Pkts_Dropped_CPDA -x "Traffic" -y "Pkts_Dropped" -t "Traffic Vs Pkts_Dropped" -lw 2 -tk -P -ly -2e3,4e3
xgraph Avg_Energy_CPDA -x "Traffic" -y "Avg_Energy" -t "Traffic Vs Average_Energy_Consumptions" -lw 2 -tk -P -ly -1,2
xgraph Residual_Energy_CPDA -x "Traffic" -y "Residual_Energy" -t "Traffic Vs Average_Residual_Energy" -lw 2 -tk -P -ly 98,100
xgraph Jitter_CPDA -x "Traffic" -y "Jitter" -t "Traffic Vs Jitter" -lw 2 -tk -P -ly -50e-3,140e-3
xgraph Throughput_CPDA -x "Traffic" -y "Throughput" -t "Traffic Vs Throughput" -lw 2 -tk -P -ly -100e3,560e3




