xgraph PDR_CPDA -x "Simulation_time" -y "PDR" -t "Simulation_time Vs PDR" -lw 2 -tk -P -ly 96,101
xgraph Delay_CPDA -x "Simulation_time" -y "Delay" -t "Simulation_time Vs Delay" -lw 2 -tk -P -ly -100e-3,400e-3
xgraph Control_OH_CPDA -x "Simulation_time" -y "Control_overhead" -t "Simulation_time Vs Control_overhead" -lw 2 -tk -P
xgraph Normalized_OH_CPDA -x "Simulation_time" -y "Normalized_Overheads" -t "Simulation_time Vs Normalized_Overheads" -lw 2 -tk -P -ly 5.90,7
xgraph Dropping_Ratio_CPDA -x "Simulation_time" -y "Dropping_Ratio" -t "Simulation_time Vs Dropping_Ratio" -lw 2 -tk -P -ly -2,3
xgraph Pkts_Dropped_CPDA -x "Simulation_time" -y "Pkts_Dropped" -t "Simulation_time Vs Pkts_Dropped" -lw 2 -tk -P -ly -10,30
xgraph Avg_Energy_CPDA -x "Simulation_time" -y "Avg_Energy" -t "Simulation_time Vs Average_Energy_Consumptions" -lw 2 -tk -P 
xgraph Residual_Energy_CPDA -x "Simulation_time" -y "Residual_Energy" -t "Simulation_time Vs Average_Residual_Energy" -lw 2 -tk -P 
xgraph Jitter_CPDA -x "Simulation_time" -y "Jitter" -t "Simulation_time Vs Jitter" -lw 2 -tk -P -ly 96e-3,106e-3
xgraph Throughput_CPDA -x "Simulation_time" -y "Throughput" -t "Simulfsation_time Vs Throughput" -lw 2 -tk -P -ly 152e3,162e3




