xgraph PDR_CPDA -x "Speed" -y "PDR" -t "Speed Vs PDR" -lw 2 -tk -P -ly 97,102
xgraph Delay_CPDA -x "Speed" -y "Delay" -t "Speed Vs Delay" -lw 2 -tk -P -ly -100e-3,300e-3
xgraph Control_OH_CPDA -x "Speed" -y "Control_overhead" -t "Speed Vs Control_overhead" -lw 2 -tk -P -ly 10.6e3,12e3
xgraph Normalized_OH_CPDA -x "Speed" -y "Normalized_Overheads" -t "Speed Vs Normalized_Overheads" -lw 2 -tk -P -ly 6,6.55
xgraph Dropping_Ratio_CPDA -x "Speed" -y "Dropping_Ratio" -t "Speed Vs Dropping_Ratio" -lw 2 -tk -P -ly -100e-3,900e-3
xgraph Pkts_Dropped_CPDA -x "Speed" -y "Pkts_Dropped" -t "Speed Vs Pkts_Dropped" -lw 2 -tk -P -ly -3,16
xgraph Avg_Energy_CPDA -x "Speed" -y "Avg_Energy" -t "Speed Vs Average_Energy_Consumptions" -lw 2 -tk -P -ly 250e-3,700e-3
xgraph Residual_Energy_CPDA -x "Speed" -y "Residual_Energy" -t "Speed Vs Average_Residual_Energy" -lw 2 -tk -P -ly 99,100
xgraph Jitter_CPDA -x "Speed" -y "Jitter" -t "Speed Vs Jitter" -lw 2 -tk -P -ly 97e-3,102.50e-3
xgraph Throughput_CPDA -x "Speed" -y "Throughput" -t "Speed Vs Throughput" -lw 2 -tk -P -ly 156e3,163e3




