xgraph PDR_CPDA -x "Interval" -y "PDR" -t "Interval Vs PDR" -lw 2 -tk -P -ly 96,102
xgraph Delay_CPDA -x "Interval" -y "Delay" -t "Interval Vs Delay" -lw 2 -tk -P -ly 0e-3,200e-3
xgraph Control_OH_CPDA -x "Interval" -y "Control_overhead" -t "Interval Vs Control_overhead" -lw 2 -tk -P -ly 11e3,11.40e3
xgraph Normalized_OH_CPDA -x "Interval" -y "Normalized_Overheads" -t "Interval Vs Normalized_Overheads" -lw 2 -tk -P 
xgraph Dropping_Ratio_CPDA -x "Interval" -y "Dropping_Ratio" -t "Interval Vs Dropping_Ratio" -lw 2 -tk -P -ly -2,3
xgraph Pkts_Dropped_CPDA -x "Interval" -y "Pkts_Dropped" -t "Interval Vs Pkts_Dropped" -lw 2 -tk -P -ly -3,9
xgraph Avg_Energy_CPDA -x "Interval" -y "Avg_Energy" -t "Interval Vs Average_Energy_Consumptions" -lw 2 -tk -P -ly -100e-3,350e-3
xgraph Residual_Energy_CPDA -x "Interval" -y "Residual_Energy" -t "Interval Vs Average_Residual_Energy" -lw 2 -tk -P -ly 99,100.60
xgraph Jitter_CPDA -x "Interval" -y "Jitter" -t "Interval Vs Jitter" -lw 2 -tk -P
xgraph Throughput_CPDA -x "Interval" -y "Throughput" -t "Interval Vs Throughput" -lw 2 -tk -P -ly -50e3,130e3




